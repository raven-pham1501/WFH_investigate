#include "thread_1.h"
#include "common_utils.h"

/* thread_1 entry function */
/* pvParameters contains TaskHandle_t */
void thread_1_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);

    /* TODO: add your own code here */
    while (1)
    {
        vTaskDelay (1);
    }
}
