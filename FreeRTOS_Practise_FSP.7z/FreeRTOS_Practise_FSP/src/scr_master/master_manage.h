/*
 * master_manage.h
 *
 *  Created on: Mar 15, 2024
 *      Author: huy.pham-manh
 */

#ifndef SCR_MASTER_MASTER_MANAGE_H_
#define SCR_MASTER_MASTER_MANAGE_H_

#include "thread_master.h"

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/\
#define EP_INFO             "\r\nThe example project demonstrates the functionalities of WiFi_OnChip_Silex   " \
                            "\r\nrunning on Renesas RA MCUs using Renesas Silex UART Pmod hardware.          " \
                            "\r\nThe project gives user option to either scan WiFi networks or manually      " \
                            "\r\nenter network credentials in JlinkRTTViewer and connect. Then it performs   " \
                            "\r\nping operation on user entered URL or IP address.  If successful,           " \
                            "\r\n'Ping Successful'message printed on JlinkRTTViewer. The project also        " \
                            "\r\ndemonstrates TCP socket operations in client mode. It tries connecting to   " \
                            "\r\nthe user entered TCP server IP address and port number. It is expected      " \
                            "\r\nthat TCP socket in server mode would be running on user PC and listening    " \
                            "\r\non a free port before the EP tries to connect. Once connected to the TCP    " \
                            "\r\nserver, the user should send 'on' or 'off' message from the server.         " \
                            "\r\nBased on the message, on-board user LED would turn on/off and the same      " \
                            "\r\nwould be displayed on JlinkRTTViewer. If an invalid message is received,    " \
                            "\r\nthen previous LED state would be maintained. After receiving messages from   "\
                            "\r\nthe server, appropriate acknowledgment  messages are sent to the server.\r\n"


#define EP_OPTION           "\r\nMenu:" \
		                    "\r\n-----------DS1307_MODULES------------------------      " \
							"\r\nPress 1 to read real time every 5 second               " \
							"\r\nPress 2 to write real time                             " \
							"\r\nPress 3 to read high time and low time every 5 second  " \
							"\r\n                                                       " \
							"\r\n-----------PWM_MODULES---------------------------      " \
							"\r\nPress 4 to read frequency and duty cycle data          " \
							"\r\nPress 5 to write frequency and duty cycle data to check" \
							"\r\n                                                       " \
							"\r\n-----------TEMPERATURE_INSIDE_MCU----------------      " \
							"\r\nPress 6 to read temperature inside MCU                 " \
							"\r\n                                                       " \
							"\r\n-----------UART_LOOPBACK-------------------------      " \
							"\r\nPress 7 to read data from TX_MCU                       " \
							"\r\nPress 8 to write data to RX_MCU                        " \
							"\r\n                                                       " \
                            "\r\n-----------W25QXX_MODULES------------------------      " \
							"\r\nPress 9 to read data by TX                             " \
							"\r\nPress 10 to write data by RX                           " \
							"\r\n"

 /* Macros and variables for RTT operations */
 #define BUFF_LEN                    (32U)
 #define BYTES_RECEIVED_ZERO         (0U)

 /* Macro for Menu Options */
 #define READ_DS1307                    (1U)
 #define WRITE_DS1307                   (2U)
 #define READ_HIGH_LOW_TIME_DS1307      (3U)
 #define READ_PWM                       (4U)
 #define WRITE_PWM                      (5U)
 #define READ_TEMPERATURE_MCU           (6U)
 #define READ_UART                      (7U)
 #define WRITE_UART                     (8U)
 #define READ_W25QXX                    (9U)
 #define WRITE_W25QXX                   (10U)
 #define EXIT                           (11U)

 /* Macros for array indexing */
 #define INDEX_ZERO      (0U)
 #define INDEX_ONE       (1U)
 #define INDEX_TWO       (2U)
 #define INDEX_THREE     (3U)

 /* user LED*/
 #if defined (BOARD_RA4M3_EK)
 #define USER_LED (BSP_IO_PORT_03_PIN_07)
 #endif

 /***********************************************************************************************************************
  * User-defined APIs
  **********************************************************************************************************************/
 void user_input(char * user_buff);

#endif /* SCR_MASTER_MASTER_MANAGE_H_ */
