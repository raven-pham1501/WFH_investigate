/*
 * master_manage.c
 *
 *  Created on: Mar 15, 2024
 *      Author: huy.pham-manh
 */


#include "common_utils.h"
#include "master_manage.h"

/*******************************************************************************************************************//**
 * @brief       This functions takes input from user.
 * @param[IN]   char pointer pointing to user input buffer.
 * @retval      None.
 * @retval      None.
 **********************************************************************************************************************/
void user_input(char * user_buff)
{
    char rByte[BUFF_LEN];           // RTT buffer to read data
    uint32_t num_bytes;             // Number of bytes read by RTT

    /* Resetting user_buff */
    memset(user_buff, RESET_VALUE, BUFF_LEN);

    num_bytes = RESET_VALUE;
    while (BYTES_RECEIVED_ZERO == num_bytes)
    {
        if (APP_CHECK_DATA)
        {
            num_bytes = (uint32_t) APP_READ(rByte);
            if(BYTES_RECEIVED_ZERO == num_bytes)
            {
                APP_PRINT("\r\nNo Input\r\n");
            }
        }
    }

    switch(rByte[num_bytes - INDEX_ONE])
    {
        case '\r':
        {
            rByte[num_bytes - INDEX_ONE] = '\0';
            memcpy(user_buff, rByte, (size_t) num_bytes);
        }
        break;
        case '\n':
        {
            if('\r' == rByte[num_bytes - INDEX_TWO])
            {
                rByte[num_bytes - INDEX_TWO] = '\0';
                rByte[num_bytes - INDEX_ONE] = '\0';
                memcpy(user_buff, rByte, (size_t) (num_bytes - INDEX_ONE));
            }
            else
            {
                rByte[num_bytes - INDEX_ONE] = '\0';
                memcpy(user_buff, rByte, (size_t) num_bytes);
            }
        }
        break;
        default:
        {
            memcpy(user_buff, rByte, (size_t) num_bytes);
        }
        break;
    }
}
