#include "common_utils.h"
#include "scr_master/master_manage.h"

/* thread_master entry function */
/* pvParameters contains TaskHandle_t */
void thread_master_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);

    fsp_err_t err = FSP_SUCCESS;
    fsp_pack_version_t version = {RESET_VALUE};

    char input_buff[BUFF_LEN] = {RESET_VALUE};          // Buffer for storing user input generally

    uint8_t index_menu_option = RESET_VALUE;            // Index to store menu option selected
    uint8_t flag_status = RESET_VALUE;                  // flag to reset menu option selected


    char input_DMoY_buff[BUFF_LEN] = {RESET_VALUE};      // Buffer for storing user input  of DS1307 module
    char input_HMiY_buff[BUFF_LEN] = {RESET_VALUE};      // Buffer for storing user input  of DS1307 module

    uint16_t frequency_input = RESET_VALUE;             // frequency input of PWM modules
    uint16_t pwm_input = RESET_VALUE;                    // Duty Cycle input of PWM modules


    /* version get API for FLEX pack information */
    R_FSP_VersionGet(&version);

    /* Project information printed on the Console */
    APP_PRINT(BANNER_INFO, EP_VERSION, version.version_id_b.major, version.version_id_b.minor, version.version_id_b.patch);
    //APP_PRINT(EP_INFO);
    APP_PRINT(EP_OPTION);

    APP_PRINT("\r\nUser Input: \r\n");


    if(FSP_SUCCESS != err)
    {
        APP_ERR_PRINT("\r\n again.\r\n");
    }
    /* TODO: add your own code here */
    while (1)
    {
        if (flag_status == RESET_VALUE)
        {
            user_input(input_buff);

            index_menu_option = (uint8_t)atoi((char *) input_buff);

            switch(index_menu_option)
            {
                case READ_DS1307:
                    APP_PRINT("\r\n Active READ_DS1307 \r\n");
                    flag_status++;
                    break;

                case WRITE_DS1307:
                    APP_PRINT("\r\n Active WRITE_DS1307 \r\n");

                    APP_PRINT("\r\n Write to WRITE_DS1307 format Day-Month-Year \r\n");
                    user_input(input_DMoY_buff);

                    APP_PRINT("\r\n Write to WRITE_DS1307 format Hour-Minute-Second \r\n");
                    user_input(input_HMiY_buff);

                    APP_PRINT("\r\n Wrote to WRITE_W25QXX: %s %s \r\n", input_DMoY_buff, input_HMiY_buff);
                    flag_status++;
                    break;

                case READ_HIGH_LOW_TIME_DS1307:
                    APP_PRINT("\r\n Active READ_HIGH_LOW_TIME_DS1307 \r\n");
                    flag_status++;
                    break;

                case READ_PWM:
                    APP_PRINT("\r\n Active READ_PWM \r\n");
                    flag_status++;
                    break;

                case WRITE_PWM:
                    APP_PRINT("\r\n Active WRITE_PWM \r\n");

                    APP_PRINT("\r\n Write to Frequency Hz: \r\n");
                    user_input(input_buff);
                    frequency_input = (uint8_t)atoi((char *) input_buff);

                    APP_PRINT("\r\n Write to Duty Cycle 1-100 %%: \r\n");
                    user_input(input_buff);
                    pwm_input = (uint8_t)atoi((char *) input_buff);

                    APP_PRINT("\r\n Wrote to WRITE_PWM: %d Hz %d %% \r\n", frequency_input ,pwm_input);
                    flag_status++;
                    break;

                case READ_TEMPERATURE_MCU:
                    APP_PRINT("\r\n Active READ_TEMPERATURE_MCU \r\n");
                    flag_status++;
                    break;

                case READ_UART:
                    APP_PRINT("\r\n Active READ_UART \r\n");
                    flag_status++;
                    break;

                case WRITE_UART:
                    APP_PRINT("\r\n Active WRITE_UART \r\n");

                    APP_PRINT("\r\n Write to MCU \r\n");
                    user_input(input_buff);

                    APP_PRINT("\r\n Wrote to MCU : %s \r\n", input_buff);
                    flag_status++;
                    break;

                case READ_W25QXX:
                    APP_PRINT("\r\n Active READ_W25QXX \r\n");
                    flag_status++;
                    break;

                case WRITE_W25QXX:
                    APP_PRINT("\r\n Active WRITE_W25QXX \r\n");

                    APP_PRINT("\r\n Write to W25QXX \r\n");
                    user_input(input_buff);

                    APP_PRINT("\r\n Wrote to W25QXX : %s \r\n", input_buff);
                    flag_status++;
                    break;

                case EXIT:
                    break;

                default:
                    APP_PRINT("\r\nInvalid Input.\r\n");
                    break;
            }
        }

        flag_status = RESET_VALUE;

        vTaskDelay (1);
    }
}
