#include "thread_4.h"
/* thread_4 entry function */
/* pvParameters contains TaskHandle_t */
void thread_4_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);

    /* TODO: add your own code here */
    while (1)
    {
        vTaskDelay (1);
    }
}
