#include "thread_3.h"
/* thread_3 entry function */
/* pvParameters contains TaskHandle_t */
void thread_3_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);

    /* TODO: add your own code here */
    while (1)
    {
        vTaskDelay (1);
    }
}
