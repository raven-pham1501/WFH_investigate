/* generated configuration header file - do not edit */
#ifndef R_DTC_CFG_H_
#define R_DTC_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define DTC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define DTC_CFG_VECTOR_TABLE_SECTION_NAME ".fsp_dtc_vector_table"

#ifdef __cplusplus
}
#endif
#endif /* R_DTC_CFG_H_ */
