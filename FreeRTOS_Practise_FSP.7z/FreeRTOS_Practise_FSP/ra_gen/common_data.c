/* generated common source file - do not edit */
#include "common_data.h"
ioport_instance_ctrl_t g_ioport_ctrl;
const ioport_instance_t g_ioport =
{ .p_api = &g_ioport_on_ioport, .p_ctrl = &g_ioport_ctrl, .p_cfg = &g_bsp_pin_cfg, };
QueueHandle_t g_queue_i2c;
#if 1
StaticQueue_t g_queue_i2c_memory;
uint8_t g_queue_i2c_queue_memory[4 * 20];
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
QueueHandle_t g_queue_spi;
#if 1
StaticQueue_t g_queue_spi_memory;
uint8_t g_queue_spi_queue_memory[4 * 20];
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_mutex_uart;
#if 1
StaticSemaphore_t g_mutex_uart_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
QueueHandle_t g_queue_uart;
#if 1
StaticQueue_t g_queue_uart_memory;
uint8_t g_queue_uart_queue_memory[4 * 20];
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
void g_common_init(void)
{
    g_queue_i2c =
#if 1
            xQueueCreateStatic (
#else
                xQueueCreate(
                #endif
                                20,
                                4
#if 1
                                ,
                                &g_queue_i2c_queue_memory[0], &g_queue_i2c_memory
#endif
                                );
    if (NULL == g_queue_i2c)
    {
        rtos_startup_err_callback (g_queue_i2c, 0);
    }
    g_queue_spi =
#if 1
            xQueueCreateStatic (
#else
                xQueueCreate(
                #endif
                                20,
                                4
#if 1
                                ,
                                &g_queue_spi_queue_memory[0], &g_queue_spi_memory
#endif
                                );
    if (NULL == g_queue_spi)
    {
        rtos_startup_err_callback (g_queue_spi, 0);
    }
    g_mutex_uart =
#if 0
                #if 1
                xSemaphoreCreateRecursiveMutexStatic(&g_mutex_uart_memory);
                #else
                xSemaphoreCreateRecursiveMutex();
                #endif
                #else
#if 1
            xSemaphoreCreateMutexStatic (&g_mutex_uart_memory);
#else
                xSemaphoreCreateMutex();
                #endif
#endif
    if (NULL == g_mutex_uart)
    {
        rtos_startup_err_callback (g_mutex_uart, 0);
    }
    g_queue_uart =
#if 1
            xQueueCreateStatic (
#else
                xQueueCreate(
                #endif
                                20,
                                4
#if 1
                                ,
                                &g_queue_uart_queue_memory[0], &g_queue_uart_memory
#endif
                                );
    if (NULL == g_queue_uart)
    {
        rtos_startup_err_callback (g_queue_uart, 0);
    }
}
