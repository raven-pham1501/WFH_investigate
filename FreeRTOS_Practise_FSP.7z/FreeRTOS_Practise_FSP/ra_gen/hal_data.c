/* generated HAL source file - do not edit */
#include "hal_data.h"
void g_hal_init(void)
{
    g_common_init ();
}
