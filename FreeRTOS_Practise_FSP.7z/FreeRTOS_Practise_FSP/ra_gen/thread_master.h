/* generated thread header file - do not edit */
#ifndef THREAD_MASTER_H_
#define THREAD_MASTER_H_
#include "bsp_api.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "hal_data.h"
#ifdef __cplusplus
                extern "C" void thread_master_entry(void * pvParameters);
                #else
extern void thread_master_entry(void *pvParameters);
#endif
FSP_HEADER
FSP_FOOTER
#endif /* THREAD_MASTER_H_ */
